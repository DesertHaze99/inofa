<div class="card page-header page-header-light">
    <div class="page-header-content header-elements-md-inline">
        <div class="page-title">
            <h2><span class="font-weight-semibold mx-2">INOVA</span> - Tambah Bentuk Obat Baru</h2>
            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>
    </div>
    <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
	    <div class="d-flex">
	        <div class="breadcrumb">
	            <a href="index.html" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Bentuk Obat</a>
	            <span class="breadcrumb-item active">Dashboard</span>
	        </div>
	        <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
	    </div>
	</div>
</div>
<!-- /page header -->
